<?php
const BASE_URL = "http://localhost/PInmasic/";
const HOST = "localhost";
const USER = "root";
const PASS = "root";
const DB = "gestion_archivos";
const CHARSET = "charset=utf8";
?>